package com.example.todolist1;



import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private DatabaseHelper databaseHelper;
    private TaskAdapter taskAdapter;
    private List<Task> taskList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseHelper = new DatabaseHelper(this);
        taskList = databaseHelper.getAllTasks();

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        taskAdapter = new TaskAdapter(taskList, new TaskAdapter.OnItemClickListener() {
            @Override
            public void onEdit(Task task) {
                showEditTaskDialog(task);
            }

            @Override
            public void onDelete(Task task) {
                databaseHelper.deleteTask(task.getId());
                taskList.remove(task);
                taskAdapter.notifyDataSetChanged();
            }
        });

        recyclerView.setAdapter(taskAdapter);

        Button addTaskButton = findViewById(R.id.addTaskButton);
        addTaskButton.setOnClickListener(v -> showAddTaskDialog());
    }

    private void showAddTaskDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_add_task, null);
        builder.setView(dialogView);

        EditText editTextTaskTitle = dialogView.findViewById(R.id.editTextTaskTitle);
        EditText editTextDueDate = dialogView.findViewById(R.id.editTextDueDate);
        Button buttonSave = dialogView.findViewById(R.id.buttonSave);

        AlertDialog dialog = builder.create();

        buttonSave.setOnClickListener(v -> {
            String taskTitle = editTextTaskTitle.getText().toString().trim();
            String dueDate = editTextDueDate.getText().toString().trim();

            if (!taskTitle.isEmpty()) {
                Task newTask = new Task(0, taskTitle, dueDate);
                databaseHelper.addTask(newTask);
                taskList.add(newTask);
                taskAdapter.notifyDataSetChanged();
                dialog.dismiss();
            } else {
                editTextTaskTitle.setError("Task title is required");
            }
        });

        dialog.show();
    }

    private void showEditTaskDialog(Task task) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_add_task, null);
        builder.setView(dialogView);

        EditText editTextTaskTitle = dialogView.findViewById(R.id.editTextTaskTitle);
        EditText editTextDueDate = dialogView.findViewById(R.id.editTextDueDate);
        Button buttonSave = dialogView.findViewById(R.id.buttonSave);

        editTextTaskTitle.setText(task.getTitle());
        editTextDueDate.setText(task.getDueDate());

        AlertDialog dialog = builder.create();

        buttonSave.setOnClickListener(v -> {
            String taskTitle = editTextTaskTitle.getText().toString().trim();
            String dueDate = editTextDueDate.getText().toString().trim();

            if (!taskTitle.isEmpty()) {
                task.setTitle(taskTitle);
                task.setDueDate(dueDate);
                databaseHelper.updateTask(task);
                taskAdapter.notifyDataSetChanged();
                dialog.dismiss();
            } else {
                editTextTaskTitle.setError("Task title is required");
            }
        });

        dialog.show();
    }
}
